class FuncionarioRepository:
    