#from database.conexao import Conexao
from datetime import date
from models.funcionario import Funcionario

def main():
    #conexao = Conexao()
    #print("Conexão realizada com sucesso!")

    #conexao.fechar()

    funcionario = Funcionario(nome = "Alanis da Silva", 
                                  cpf = "12345678998", 
                                  cargo = "TI Dev",
                                  departamento = "TECH",
                                  salario = 4000.00,
                                  data_admissao = date.today())
    
    funcionario.__str__()
if __name__ == "__main__":
    main()